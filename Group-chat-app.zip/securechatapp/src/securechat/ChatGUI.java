package securechat;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ChatGUI extends JFrame{

    private static final Color SKY_BLUE = new Color(173, 216, 230);
    private static final Color LIGHT_BLUE = new Color(230, 245, 255);

    private final ChatClient client;

    private final JTextArea chatArea = new JTextArea();
    private final JTextField inputField = new JTextField();
    private final JButton sendButton = new JButton("Send");
    private final JButton emojiButton = new JButton("😊");

    private final DefaultListModel<String> userListModel = new DefaultListModel<>();
    private final JList<String> userList = new JList<>(userListModel);

    // Track all open private windows
    private final Map<String, PrivateChatGUI> privateWindows = new HashMap<>();

    public ChatGUI(ChatClient client) {
        this.client = client;

        setTitle("SecureCampusChat - " + client.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);

        initUI();
        startReceiverThread();

        setVisible(true);
    }

    private void initUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(SKY_BLUE); // whole window background

        // ===========================================================
        // LEFT USER LIST PANEL
        // ===========================================================
        userList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userList.setFont(new Font("SansSerif", Font.PLAIN, 14));
        userList.setBackground(LIGHT_BLUE);  // sky-blue tint inside list

        JScrollPane userPane = new JScrollPane(userList);
        userPane.setPreferredSize(new Dimension(150, 0));
        userPane.setBorder(BorderFactory.createTitledBorder("Online Users"));
        userPane.getViewport().setBackground(LIGHT_BLUE);

        add(userPane, BorderLayout.WEST);

        // Double click → open private chat
        userList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String target = userList.getSelectedValue();
                    if (target != null && !target.equals(client.getUsername())) {
                        openPrivateChat(target);
                    }
                }
            }
        });

        // ===========================================================
        // CHAT AREA (CENTER)
        // ===========================================================
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        chatArea.setBackground(LIGHT_BLUE);

        JScrollPane chatScroll = new JScrollPane(chatArea);
        chatScroll.getViewport().setBackground(LIGHT_BLUE);

        add(chatScroll, BorderLayout.CENTER);

        // ===========================================================
        // INPUT PANEL (BOTTOM)
        // ===========================================================
        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBackground(SKY_BLUE);

        inputField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        inputField.setBackground(Color.WHITE);
        inputPanel.add(inputField, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 3, 0));
        buttonsPanel.setBackground(SKY_BLUE);
        buttonsPanel.add(emojiButton);
        buttonsPanel.add(sendButton);

        inputPanel.add(buttonsPanel, BorderLayout.EAST);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        add(inputPanel, BorderLayout.SOUTH);

        // ===========================================================
        // EVENT LISTENERS
        // ===========================================================
        sendButton.addActionListener(e -> sendCurrentMessage());
        inputField.addActionListener(e -> sendCurrentMessage());

        // Emoji menu
        JPopupMenu emojiMenu = new JPopupMenu();
        for (String em : new String[]{"😊", "😂", "❤️", "👍", "🔥", "🎉", "😢", "🤔"}) {
            JMenuItem item = new JMenuItem(em);
            item.addActionListener(ev -> inputField.setText(inputField.getText() + em));
            emojiMenu.add(item);
        }

        emojiButton.addActionListener(e ->
                emojiMenu.show(emojiButton, 0, emojiButton.getHeight())
        );
    }

    private void sendCurrentMessage() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;

        client.sendMessage(text);
        inputField.setText("");
    }

    private void startReceiverThread() {
        Thread t = new Thread(() -> {
            try {
                String line;
                while ((line = client.receiveMessage()) != null) {
                    handleIncoming(line);
                }
            } catch (Exception ignored) {}
        });
        t.setDaemon(true);
        t.start();
    }

    private void handleIncoming(String msg) {
        if (msg == null || msg.isEmpty()) return;

        SwingUtilities.invokeLater(() -> {

            // PRIVATE MESSAGE
            if (msg.startsWith("PRIVATE|")) {
                String[] parts = msg.split("\\|", 3);
                String sender = parts[1];
                String text = parts[2];

                PrivateChatGUI window = privateWindows.get(sender);
                if (window == null) window = openPrivateChat(sender);
                window.receiveMessage(sender, text);
                return;
            }

            // USER LIST UPDATE
            if (msg.startsWith("USERS|")) {
                updateUserList(msg.substring(6));
                return;
            }

            chatArea.append(msg + "\n");
            chatArea.setCaretPosition(chatArea.getDocument().getLength());
        });
    }

    private void updateUserList(String csv) {
        userListModel.clear();
        for (String u : csv.split(",")) {
            if (!u.isBlank()) userListModel.addElement(u);
        }
    }

    private PrivateChatGUI openPrivateChat(String targetUser) {
        if (privateWindows.containsKey(targetUser)) {
            PrivateChatGUI window = privateWindows.get(targetUser);
            window.setVisible(true);
            this.setVisible(false);
            return window;
        }

        PrivateChatGUI win = new PrivateChatGUI(client, client.getUsername(), targetUser, this);
        privateWindows.put(targetUser, win);

        this.setVisible(false);
        win.setVisible(true);
        return win;
    }
}
