package securechat;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PrivateChatGUI extends JFrame{

    private static final Color SKY_BLUE = new Color(173, 216, 230);

    private final ChatClient client;
    private final String sender;
    private final String receiver;
    private final ChatGUI parent;

    private final JTextArea chatArea = new JTextArea();
    private final JTextField inputField = new JTextField();
    private final JButton sendButton = new JButton("Send");
    private final JButton emojiButton = new JButton("😊");

    public PrivateChatGUI(ChatClient client, String sender, String receiver, ChatGUI parent) {
        this.client = client;
        this.sender = sender;
        this.receiver = receiver;
        this.parent = parent;

        setTitle("Private Chat: " + sender + " → " + receiver);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        initUI();
        setVisible(true);
    }

    private void initUI() {

        getContentPane().setBackground(SKY_BLUE);
        setLayout(new BorderLayout());

        // ---- CHAT AREA ----
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        chatArea.setBackground(new Color(230, 245, 255)); // lighter blue

        JScrollPane scrollPane = new JScrollPane(chatArea);
        add(scrollPane, BorderLayout.CENTER);

        // ---- INPUT PANEL ----
        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBackground(SKY_BLUE);

        inputField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        inputPanel.add(inputField, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 3, 0));
        buttonsPanel.setBackground(SKY_BLUE);
        buttonsPanel.add(emojiButton);
        buttonsPanel.add(sendButton);
        inputPanel.add(buttonsPanel, BorderLayout.EAST);

        inputPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        add(inputPanel, BorderLayout.SOUTH);

        // ---- EMOJI MENU ----
        final JPopupMenu emojiMenu = new JPopupMenu();
        String[] emojis = {"😊", "😂", "❤️", "👍", "🔥", "🎉", "😢", "🤔"};

        for (String em : emojis) {
            JMenuItem item = new JMenuItem(em);
            item.addActionListener(ev -> inputField.setText(inputField.getText() + em));
            emojiMenu.add(item);
        }

        emojiButton.addActionListener(e ->
                emojiMenu.show(emojiButton, 0, emojiButton.getHeight())
        );

        sendButton.addActionListener(e -> send());
        inputField.addActionListener(e -> send());

        // Restore group chat on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                parent.setVisible(true);
            }
        });
    }

    private void send() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;

        client.sendPrivate(receiver, text);
        chatArea.append("Me: " + text + "\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
        inputField.setText("");
    }

    public void receiveMessage(String from, String msg) {
        chatArea.append(from + ": " + msg + "\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }
}
