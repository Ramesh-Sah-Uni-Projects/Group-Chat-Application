package securechat;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientHandler extends Thread{

    private final ChatServer server;
    private final DatabaseManager db;
    private final Socket socket;

    private BufferedReader in;
    private PrintWriter out;
    private User user;

    public ClientHandler(ChatServer server, Socket socket, DatabaseManager db) {
        this.server = server;
        this.socket = socket;
        this.db = db;
    }

    @Override
    public void run() {
        try {
            in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String line;
            while ((line = in.readLine()) != null) {
                if (line.startsWith("REGISTER")) {
                    handleRegister(line);
                } else if (line.startsWith("LOGIN")) {
                    handleLogin(line);
                } else if (line.startsWith("MSG")) {
                    handleMsg(line.substring(4));
                } else if (line.startsWith("PRIVATE")) {
                    handlePrivate(line);
                }
            }
        } catch (Exception e) {
            // connection dropped
        } finally {
            try {
                if (socket != null) socket.close();
            } catch (Exception ignored) {}
            if (user != null) {
                server.broadcast(user.getUsername() + ": left", this);
            }
            server.remove(this);
            server.broadcastUserList();
        }
    }

    private void handleRegister(String line) {
        String[] parts = line.split(" ", 3);
        if (parts.length < 3) {
            out.println("ERROR");
            return;
        }
        String username = parts[1];
        String password = parts[2];
        boolean ok = db.registerUser(username, password, UserRole.STUDENT);
        out.println(ok ? "OK" : "ERROR");
    }

    private void handleLogin(String line) {
        String[] parts = line.split(" ", 3);
        if (parts.length < 3) {
            out.println("ERROR");
            return;
        }
        String username = parts[1];
        String password = parts[2];

        User u = db.loginUser(username, password);
        if (u != null) {
            user = u;
            out.println("OK");
            server.broadcast(user.getUsername() + ": joined", this);
            server.broadcastUserList();
        } else {
            out.println("ERROR");
        }
    }

    private void handleMsg(String msg) {
        if (user == null) {
            out.println("ERROR");
            return;
        }
        server.broadcast(user.getUsername() + ": " + msg, this);
    }


    private void handlePrivate(String line) {
        if (user == null) {
            out.println("ERROR");
            return;
        }
        // Format: PRIVATE targetUser message...
        String[] parts = line.split(" ", 3);
        if (parts.length < 3) {
            out.println("ERROR");
            return;
        }
        String target = parts[1];
        String text = parts[2];
        server.sendPrivate(user.getUsername(), target, text);
    }

    String getUsername() {
        return user != null ? user.getUsername() : null;
    }
    void send(String msg) {
        out.println(msg);
    }
}
