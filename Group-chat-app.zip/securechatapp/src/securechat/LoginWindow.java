package securechat;

import javax.swing.*;
import java.awt.*;

public class LoginWindow extends JFrame {

    public LoginWindow() {
        setTitle("SecureCampusChat - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 260);
        setLocationRelativeTo(null);

        getContentPane().setBackground(new Color(173, 216, 230)); // sky blue
        getContentPane().setLayout(new BorderLayout());
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JTextField u = new JTextField();
        JPasswordField pw = new JPasswordField();

        u.setFont(new Font("Arial", Font.PLAIN, 16));
        pw.setFont(new Font("Arial", Font.PLAIN, 16));
        u.setPreferredSize(new Dimension(230, 35));
        pw.setPreferredSize(new Dimension(230, 35));

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JButton log = new JButton("Login");
        JButton reg = new JButton("Register");

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(userLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(u, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        formPanel.add(passLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(pw, gbc);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(log);
        buttonPanel.add(reg);

        getContentPane().add(formPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        log.addActionListener(e -> {
            try {
                ChatClient c = new StandardClient("localhost", 5000);
                if (c.login(u.getText(), new String(pw.getPassword()))) {
                    new ChatGUI(c);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Login failed");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error connecting to server");
            }
        });

        reg.addActionListener(e -> new RegisterWindow(this));

        setVisible(true);
    }
}
