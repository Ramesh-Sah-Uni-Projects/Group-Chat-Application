package securechat;

public enum UserRole {

    STUDENT, TEACHER, ADMIN
}
