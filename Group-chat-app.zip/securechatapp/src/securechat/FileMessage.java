package securechat;

public class FileMessage extends Message{

    private final String fileName;
    public FileMessage(String sender,String fileName){super(sender);this.fileName=fileName;}
    public String getContent(){return "[FILE] "+fileName;}
}
