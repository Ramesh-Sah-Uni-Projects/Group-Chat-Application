package securechat;

public interface EncryptionStrategy {
    String encrypt(String plain)throws Exception;
    String decrypt(String cipher)throws Exception;
}
