package securechat;
import java.security.MessageDigest;

public class PasswordHasher {

    public static String hashPassword(String p){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] h=md.digest(p.getBytes("UTF-8"));
            StringBuilder sb=new StringBuilder();
            for(byte b:h)sb.append(String.format("%02x",b));
            return sb.toString();
        }catch(Exception e){throw new RuntimeException(e);}
    }
    public static boolean verifyPassword(String p,String h){return hashPassword(p).equals(h);}

}
