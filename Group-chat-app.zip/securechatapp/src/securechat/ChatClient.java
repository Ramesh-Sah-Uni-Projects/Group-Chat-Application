package securechat;

public interface ChatClient {
    boolean login(String u,String p);
    boolean register(String u,String p);
    void sendMessage(String m);
    void sendPrivate(String toUsername, String message);
    String receiveMessage();
    String getUsername();
    void close();
}
