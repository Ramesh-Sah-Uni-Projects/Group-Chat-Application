package securechat;
import javax.crypto.Cipher;import javax.crypto.spec.SecretKeySpec;import java.util.Base64;

public class AESEncryptionStrategy implements EncryptionStrategy{

    private static final String KEY="1234567890ABCDEF";
    private SecretKeySpec getKey(){return new SecretKeySpec(KEY.getBytes(),"AES");}
    public String encrypt(String p)throws Exception{
        Cipher c=Cipher.getInstance("AES");c.init(Cipher.ENCRYPT_MODE,getKey());
        return Base64.getEncoder().encodeToString(c.doFinal(p.getBytes()));
    }
    public String decrypt(String ct)throws Exception{
        Cipher c=Cipher.getInstance("AES");c.init(Cipher.DECRYPT_MODE,getKey());
        return new String(c.doFinal(Base64.getDecoder().decode(ct)));
    }
}
