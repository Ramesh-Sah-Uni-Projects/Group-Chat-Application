package securechat;

public class SystemMessage extends Message{

    private final String text;
    public SystemMessage(String text){super("SYSTEM");this.text=text;}
    public String getContent(){return text;}
}
