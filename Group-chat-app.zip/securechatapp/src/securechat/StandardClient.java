package securechat;
import java.io.*;
import java.net.Socket;

public class StandardClient implements ChatClient{

    private Socket socket;private BufferedReader in;private PrintWriter out;private String username;
    public StandardClient(String h,int p)throws Exception{
        socket=new Socket(h,p);
        in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out=new PrintWriter(socket.getOutputStream(),true);
    }
    public boolean login(String u,String p){
        out.println("LOGIN "+u+" "+p);
        try{
            String r=in.readLine();
            if(r!=null&&r.startsWith("OK")){username=u;return true;}
        }catch(Exception e){}
        return false;
    }
    public boolean register(String u,String p){
        out.println("REGISTER "+u+" "+p);
        try{
            String r=in.readLine();
            return r!=null&&r.startsWith("OK");
        }catch(Exception e){}
        return false;
    }
    public void sendMessage(String m){out.println("MSG "+m);}
    public void sendPrivate(String toUsername, String message){out.println("PRIVATE "+toUsername+" "+message);}
    public String receiveMessage(){
        try{return in.readLine();}catch(Exception e){return null;}
    }
    public String getUsername(){return username;}
    public void close(){try{socket.close();}catch(Exception e){}}
}
