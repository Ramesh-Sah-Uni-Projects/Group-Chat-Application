package securechat;

public class NoEncryptionStrategy implements EncryptionStrategy{

    public String encrypt(String p){return p;}
    public String decrypt(String c){return c;}
}
