package securechat;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChatServer {

    private final int port;
    private final DatabaseManager db = new DatabaseManager();
    private final List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());

    public ChatServer(int port) {
        this.port = port;
    }

    public void start() {
        try (ServerSocket ss = new ServerSocket(port)) {
            while (true) {
                Socket s = ss.accept();
                ClientHandler h = new ClientHandler(this, s, db);
                clients.add(h);
                h.start();
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    void broadcast(String msg, ClientHandler from) {
        synchronized (clients) {
            for (ClientHandler c : clients) {
                c.send(msg);
            }
        }
    }


    void sendPrivate(String from, String to, String msg) {
        synchronized (clients) {
            for (ClientHandler c : clients) {
                String username = c.getUsername();
                if (username != null && username.equals(to)) {
                    c.send("PRIVATE|" + from + "|" + msg);
                    break;
                }
            }
        }
    }

    void broadcastUserList() {
        synchronized (clients) {
            StringBuilder sb = new StringBuilder();
            for (ClientHandler c : clients) {
                String username = c.getUsername();
                if (username != null) {
                    if (sb.length() > 0) {
                        sb.append(",");
                    }
                    sb.append(username);
                }
            }
            String payload = "USERS|" + sb.toString();
            for (ClientHandler c : clients) {
                c.send(payload);
            }
        }
    }

    void remove(ClientHandler h) {
        clients.remove(h);
    }
}

