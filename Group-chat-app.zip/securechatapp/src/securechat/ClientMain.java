package securechat;

public class ClientMain {

    public static void main(String[]a){javax.swing.SwingUtilities.invokeLater(LoginWindow::new);}
}
