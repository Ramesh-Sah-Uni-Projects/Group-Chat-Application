package securechat;

public class ServerMain {

    public static void main(String[] a){new ChatServer(5000).start();}
}
