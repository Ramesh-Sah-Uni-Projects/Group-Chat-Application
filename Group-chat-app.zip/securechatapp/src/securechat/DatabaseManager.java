package securechat;
import java.sql.*;
import java.util.*;

public class DatabaseManager {

    private static final String DB_URL="jdbc:sqlite:chat.db";
    public DatabaseManager(){init();}
    private void init(){
        try(Connection c=DriverManager.getConnection(DB_URL);Statement s=c.createStatement()){
            s.executeUpdate("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT)");
        }catch(Exception e){System.err.println(e);}
    }
    public boolean registerUser(String u,String p,UserRole r){
        try(Connection c=DriverManager.getConnection(DB_URL);
            PreparedStatement ps=c.prepareStatement("INSERT INTO users(username,password_hash,role)VALUES(?,?,?)")){
            ps.setString(1,u);ps.setString(2,PasswordHasher.hashPassword(p));ps.setString(3,r.name());
            ps.executeUpdate();return true;
        }catch(Exception e){return false;}
    }
    public User loginUser(String u,String p){
        try(Connection c=DriverManager.getConnection(DB_URL);
            PreparedStatement ps=c.prepareStatement("SELECT username,password_hash,role FROM users WHERE username=?")){
            ps.setString(1,u);
            ResultSet rs=ps.executeQuery();
            if(!rs.next())return null;
            if(!PasswordHasher.verifyPassword(p,rs.getString("password_hash")))return null;
            return new User(u,UserRole.valueOf(rs.getString("role")));
        }catch(Exception e){return null;}
    }

    public java.util.List<String> getAllUsernames(){
        java.util.List<String> list=new java.util.ArrayList<>();
        try(Connection c=DriverManager.getConnection(DB_URL);
            Statement s=c.createStatement();
            ResultSet rs=s.executeQuery("SELECT username FROM users ORDER BY username")){
            while(rs.next()){
                list.add(rs.getString("username"));
            }
        }catch(Exception e){System.err.println(e);}
        return list;
    }
}
