package securechat;

public class TextMessage extends Message{

    private final String text;
    public TextMessage(String sender,String text){super(sender);this.text=text;}
    public String getContent(){return text;}
}
