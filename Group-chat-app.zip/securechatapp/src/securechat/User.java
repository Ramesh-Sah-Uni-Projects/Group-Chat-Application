package securechat;

public class User {

    private final String username;
    private final UserRole role;
    public User(String username, UserRole role){this.username=username;this.role=role;}
    public String getUsername(){return username;}
    public UserRole getRole(){return role;}
}
