package securechat;
import java.time.LocalDateTime;

public abstract class Message {

    protected final String sender;
    protected final LocalDateTime timestamp;
    protected Message(String sender){this.sender=sender;this.timestamp=LocalDateTime.now();}
    public String getSender(){return sender;}
    public LocalDateTime getTimestamp(){return timestamp;}
    public abstract String getContent();
}
